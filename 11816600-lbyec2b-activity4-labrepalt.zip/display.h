#ifndef DISPLAY_H_INCLUDED
#define DISPLAY_H_INCLUDED
#include "deck.h"
#include "clean.h"
deck_t *Deck;
hand_t *Player;
hand_t *Enemy;


void main_menu();
void init();
#endif // DISPLAY_H_INCLUDED
